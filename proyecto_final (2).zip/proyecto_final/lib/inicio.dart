import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: Inicio()));
}

class Inicio extends StatefulWidget {
  const Inicio({super.key});

  @override
  State<Inicio> createState() => _InicioState();
}

class _InicioState extends State<Inicio> {
  String usuarioActivo =
      'usuario1'; // Usuario activo (puedes cambiar dinámicamente)

  Map<String, List<String>> botonesPorUsuario = {
    'usuario1': ['Asignatura sin nombre'],
    // Agrega otros usuarios si quieres
  };
  Map<String, Map<String, String>> notasPorUsuario = {
    'usuario1': {'Asignatura sin nombre': ''},
    // Agrega otros usuarios si quieres
  };

  String get botonActivo => botonesPorUsuario[usuarioActivo]?.isNotEmpty == true
      ? botonesPorUsuario[usuarioActivo]!.first
      : '';
  set botonActivo(String _) {} // no usamos set, lo manejamos manualmente

  String botonActivoNombre = 'Asignatura sin nombre';
  TextEditingController controller = TextEditingController();

  void agregarBotonConNombre() {
    TextEditingController nombreController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Nombre de la materia:'),
        content: TextField(
          controller: nombreController,
          decoration: InputDecoration(
            hintText: 'Ej. Lengua II, matemáticas IV...',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              String nuevoNombre = nombreController.text.trim();
              if (nuevoNombre.isNotEmpty &&
                  !(botonesPorUsuario[usuarioActivo]?.contains(nuevoNombre) ??
                      false)) {
                setState(() {
                  notasPorUsuario[usuarioActivo]![botonActivoNombre] =
                      controller.text;
                  botonesPorUsuario[usuarioActivo]!.add(nuevoNombre);
                  notasPorUsuario[usuarioActivo]![nuevoNombre] = '';
                  botonActivoNombre = nuevoNombre;
                  controller.text = '';
                });
              }
              Navigator.pop(context);
            },
            child: Text('Agregar'),
          ),
        ],
      ),
    );
  }

  void mostrarOpcionesBoton(String nombre) {
    showDialog(
      context: context,
      builder: (context) => SimpleDialog(
        title: Text('Opciones para "$nombre"'),
        children: [
          SimpleDialogOption(
            child: Text('Cambiar nombre'),
            onPressed: () {
              Navigator.pop(context);
              cambiarNombreBoton(nombre);
            },
          ),
          SimpleDialogOption(
            child: Text('Eliminar'),
            onPressed: () {
              Navigator.pop(context);
              eliminarBoton(nombre);
            },
          ),
        ],
      ),
    );
  }

  void cambiarNombreBoton(String nombreActual) {
    TextEditingController nombreController = TextEditingController(
      text: nombreActual,
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Nuevo nombre'),
        content: TextField(
          controller: nombreController,
          decoration: InputDecoration(
            hintText: 'Nuevo nombre de la asignatura:',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              String nuevoNombre = nombreController.text.trim();
              if (nuevoNombre.isNotEmpty &&
                  nuevoNombre != nombreActual &&
                  !(botonesPorUsuario[usuarioActivo]?.contains(nuevoNombre) ??
                      false)) {
                setState(() {
                  int index = botonesPorUsuario[usuarioActivo]!.indexOf(
                    nombreActual,
                  );
                  String contenido =
                      notasPorUsuario[usuarioActivo]![nombreActual]!;
                  botonesPorUsuario[usuarioActivo]![index] = nuevoNombre;
                  notasPorUsuario[usuarioActivo]!.remove(nombreActual);
                  notasPorUsuario[usuarioActivo]![nuevoNombre] = contenido;
                  if (botonActivoNombre == nombreActual) {
                    botonActivoNombre = nuevoNombre;
                  }
                });
              }
              Navigator.pop(context);
            },
            child: Text('Guardar'),
          ),
        ],
      ),
    );
  }

  void eliminarBoton(String nombre) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Eliminar "$nombre"?'),
        content: Text('¿Deseas eliminar "$nombre"? ¡Tus notas se perderán!'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancelar'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                botonesPorUsuario[usuarioActivo]!.remove(nombre);
                notasPorUsuario[usuarioActivo]!.remove(nombre);
                if (botonActivoNombre == nombre &&
                    (botonesPorUsuario[usuarioActivo]?.isNotEmpty ?? false)) {
                  botonActivoNombre = botonesPorUsuario[usuarioActivo]!.first;
                  controller.text =
                      notasPorUsuario[usuarioActivo]![botonActivoNombre]!;
                } else if ((botonesPorUsuario[usuarioActivo]?.isEmpty ??
                    true)) {
                  botonActivoNombre = '';
                  controller.text = '';
                }
              });
              Navigator.pop(context);
            },
            child: Text('Eliminar'),
          ),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    controller.text = notasPorUsuario[usuarioActivo]![botonActivoNombre] ?? '';
  }

  @override
  Widget build(BuildContext context) {
    final botones = botonesPorUsuario[usuarioActivo] ?? [];
    final notas = notasPorUsuario[usuarioActivo] ?? {};

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 15, 102, 173),
        title: Text('NoteWork', style: TextStyle(color: Colors.white)),
        leading: IconButton(
          icon: Icon(Icons.add),
          onPressed: agregarBotonConNombre,
        ),
      ),
      body: Column(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: botones.map((nombre) {
                return GestureDetector(
                  onLongPress: () => mostrarOpcionesBoton(nombre),
                  child: Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: botonActivoNombre == nombre
                            ? Colors.blueAccent
                            : Colors.grey,
                      ),
                      onPressed: () {
                        setState(() {
                          notas[botonActivoNombre] = controller.text;
                          botonActivoNombre = nombre;
                          controller.text = notas[botonActivoNombre] ?? '';
                        });
                      },
                      child: Text(nombre),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: TextField(
                controller: controller,
                maxLines: null,
                expands: true,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Escribe tu nota aquí...',
                ),
                onChanged: (value) {
                  notas[botonActivoNombre] = value;
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
